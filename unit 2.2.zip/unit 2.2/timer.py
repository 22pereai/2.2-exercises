#!/usr/bin/env python3

from datetime import datetime, time

def main():
    print("The Timer program")
    print()

    # start timer
    input("Press Enter to start...")
    start_time = datetime.now()
    print("Start time:", str(start_time.hour) + ":" + str(start_time.minute) + ":" + str(start_time.second) + "." + str(start_time.microsecond))
    print()
    
    # stop timer
    input("Press Enter to stop...")    
    stop_time = datetime.now()
    print("Stop time:", str(stop_time.hour) + ":" + str(stop_time.minute) + ":" + str(stop_time.second) + "." + str(stop_time.microsecond))
    print()

    # calculate elapsed time
    elapsed_time = stop_time - start_time
    days = elapsed_time.days
    minutes = elapsed_time.seconds // 60
    seconds = elapsed_time.seconds % 60
    microseconds = elapsed_time.microseconds
    hours = minutes // 60
    minutes = minutes % 60

    # create time object
    time_object = time(hours, minutes, seconds, microseconds)

    # display results
    print("ELAPSED TIME")
    if days > 0:
        print("Days:", days)
        input("Press Enter to start...")
    if hours < 1:
        if minutes < 1:
            print("Time:", str(time_object.second) + "." + str(time_object.microsecond))
        else:
            print("Time:", str(time_object.minute) + ":" + str(time_object.second) + "." + str(time_object.microsecond))
    elif minutes < 1:
        print("Time:", str(time_object.hour) +  ":" + str(time_object.second) + "." + str(time_object.microsecond))
    else:
        print("Time:", str(time_object.hour) + ":" + str(time_object.minute) + ":" + str(time_object.second) + "." + str(time_object.microsecond))
    print()

if __name__ == "__main__":
    main()
