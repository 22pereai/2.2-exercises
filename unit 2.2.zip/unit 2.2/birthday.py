#!/usr/bin/env python3

from datetime import date, datetime
import datetime

x = 0

print("Welcome to the Birthday Calculator Program")
print()
name = input("Enter name: ")
while x == 0:
    month = int(input("Enter month of birth: "))
    if month > 12:
        print("Invalid Month. Input again.")
    elif month < 1:
        print("Invalid Month. Input again.")
    else:
        x = 1
while x == 1:
    day = int(input("Enter day of birth: "))
    if month == 1:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 2:
        if day > 28:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 3:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 4:
        if day > 30:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 5:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 6:
        if day > 30:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 7:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 8:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 9:
        if day > 30:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 10:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 11:
        if day > 30:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
    if month == 12:
        if day > 31:
            print("Invalid Day. Input again.")
        elif day < 1:
            print("Invalid Day. Input again.")
        else:
            x = 2
year = int(input("Enter year of birth: "))

bday = datetime.date(year, month, day)
tday = date.today()


print("Birthday:",)
print("Today:", str(tday))